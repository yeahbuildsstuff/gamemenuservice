@echo off
start "" msedge --app="https://yeahbuildsstuff.github.io/gamemenuservice/indexnew.html" --window-size=1280,720
