@echo off
start "" mshta.exe "%~dp0\install.hta"
